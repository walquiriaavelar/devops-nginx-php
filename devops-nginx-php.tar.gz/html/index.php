<?php
$mysqli = new mysqli("mysql", "root", "root", "appdb");
if ($mysqli->connect_error) {
    die("Conexão falhou: " . $mysqli->connect_error);
}
echo "Conexão OK com MySQL!";
?>
